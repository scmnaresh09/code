package test2;

@SuppressWarnings("unused")
public class Brennan {
    private Object format = null;
}
