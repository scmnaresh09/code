package test2;

public class StaticArraysMem {
    int i;
}
