package test2;

public class ArrayAndNull {
    public int[] test() {
        int[] arr = { 1, 2 };
        arr = null;
        return arr;
    }
}
