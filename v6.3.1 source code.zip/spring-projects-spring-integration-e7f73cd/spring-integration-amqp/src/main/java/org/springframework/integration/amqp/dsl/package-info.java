/**
 * Provides AMQP Component support for the Java DSL.
 */
@org.springframework.lang.NonNullApi
package org.springframework.integration.amqp.dsl;
