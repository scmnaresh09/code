---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: 'status: waiting-for-triage, type: enhancement'
assignees: ''

---

**Expected Behavior**

<!--- Tell us how it should work -->

**Current Behavior**

<!--- Explain the difference from current behavior -->

**Context**

<!--- 
How has this issue affected you?
What are you trying to accomplish?
What other alternatives have you considered?
Are you aware of any workarounds?
-->
