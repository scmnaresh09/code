/**
 * Provides Apache Cassandra Components support for the Java DSL.
 */
@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.integration.cassandra.dsl;
