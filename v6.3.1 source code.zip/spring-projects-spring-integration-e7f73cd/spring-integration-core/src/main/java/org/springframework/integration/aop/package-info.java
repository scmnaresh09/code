/**
 * Provides classes to support message publication using AOP.
 */
package org.springframework.integration.aop;
