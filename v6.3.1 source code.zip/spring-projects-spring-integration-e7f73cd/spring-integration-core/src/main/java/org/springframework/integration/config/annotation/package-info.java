/**
 * Provides classes supporting annotation-based configuration.
 */
package org.springframework.integration.config.annotation;
