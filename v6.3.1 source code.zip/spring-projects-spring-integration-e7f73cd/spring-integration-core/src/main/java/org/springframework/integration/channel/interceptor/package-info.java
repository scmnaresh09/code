/**
 * Provides classes related to channel interception.
 */
package org.springframework.integration.channel.interceptor;
