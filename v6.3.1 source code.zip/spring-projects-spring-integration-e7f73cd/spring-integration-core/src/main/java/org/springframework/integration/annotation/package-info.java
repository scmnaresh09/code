/**
 * Provides annotations for annotation-based configuration.
 */
package org.springframework.integration.annotation;
