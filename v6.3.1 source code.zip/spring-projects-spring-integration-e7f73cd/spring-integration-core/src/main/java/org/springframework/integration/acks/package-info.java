/**
 * Provides classes related to message acknowledgment.
 */
@org.springframework.lang.NonNullApi
package org.springframework.integration.acks;
