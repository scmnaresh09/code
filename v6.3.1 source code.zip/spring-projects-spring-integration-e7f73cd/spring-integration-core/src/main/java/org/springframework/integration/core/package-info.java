/**
 * Provides core classes.
 */
package org.springframework.integration.core;
