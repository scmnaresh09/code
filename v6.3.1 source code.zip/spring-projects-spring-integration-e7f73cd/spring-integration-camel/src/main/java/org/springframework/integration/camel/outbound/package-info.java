/**
 * Provides classes for Apache Camel outbound channel adapters.
 */

@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.integration.camel.outbound;
