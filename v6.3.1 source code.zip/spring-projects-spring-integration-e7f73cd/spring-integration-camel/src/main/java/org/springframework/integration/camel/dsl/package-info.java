/**
 * Provides supporting classes for JavaDSL with Apache Camel components.
 */

@org.springframework.lang.NonNullApi
@org.springframework.lang.NonNullFields
package org.springframework.integration.camel.dsl;
