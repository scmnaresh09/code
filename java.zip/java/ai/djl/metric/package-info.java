
 * Contains classes to collect metrics information.
 *
 * @see ai.djl.metric.Metric
 * @see ai.djl.metric.Metrics
 */
package ai.djl.metric;
