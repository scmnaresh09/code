---
name: Enhancement
about: Suggest an enhancement, feature request, or idea for this project
title: ''
labels: 'enhancement'
assignees: ''

---

## Description

(A clear and concise description of what the feature is.)

Will this change the current api? How?

Who will benefit from this enhancement?

## References

- list reference and related literature
- list known implementations
