package io.appium.java_client.android;

public enum GsmSignalStrength {
    NONE_OR_UNKNOWN, POOR, MODERATE, GOOD, GREAT
}
