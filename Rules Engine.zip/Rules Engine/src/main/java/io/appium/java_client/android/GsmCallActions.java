package io.appium.java_client.android;

public enum GsmCallActions {
    CALL, ACCEPT, CANCEL, HOLD
}
